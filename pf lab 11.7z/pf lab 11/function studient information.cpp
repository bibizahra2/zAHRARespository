 #include<iostream>
 using namespace std;
 struct Studentgrading{ 
	char name[10];
	int sapid;
	char address[10];
	char department[10];
	float marksSubject1;
	float marksSubject2;
};
 float calculateMaxMarks(float marksSubject1, float marksSubject2 ){
 float MaxMarks= marksSubject1; 
     if( MaxMarks<marksSubject2) 	
        MaxMarks=marksSubject2;
        return  MaxMarks;
 }
 void displayStudent(const Studentgrading&student){
   cout<<" Name:"<<name<<endl;
   cout<<"sap id :"<<sap id<<endl;
   cout<<"Address :"<<address<<endl;
   cout<<"Department :"<<department<<endl;
   cout<<"Marks for Subject1:"<<marksSubject1<<endl;
   cout<<"Marks for Subject1:"<<marksSubject2<<endl;
   cout<<"Max marks are:"<<calculateMaxMarks(marksSubject1,marksSubject2); 
 }  
 int main()
{   
  StudentGrading s1[5];
   for(int i=0; i<5; i++){
   	cout<<"Enter information for student:"<<i+1<<endl;
   	cout<<"Enter your name:"<<endl;
   	cin.ignore();
	cin.getline(s1[i].name,10);
	cout<<"Enter your sap id:"<<endl;
	cin>>s1[i].sap id;
	cout<<"Enter your address:"<<endl;
		cin.ignore();
	cin.getline(s1[i].address,10);
	
	cout<<"Enter your department:"<<endl;
		cin.ignore();
	cin.getline(s1[i].department,10);
	
	cout<<"Enter your marks for Subject1:"<<endl;
	cin>>s1[i].marksSubject1;
	
	cout<<"Enter your marks for Subject2:"<<endl;
	cin>>s1[i].marksSubject2;
	cout<<endl;
   }
    cout << "\nDisplaying Student Information:\n";
    for (int i = 0; i < 5; i++) {
    	cout<<"Information for student:"<<i+1<<endl;
        displayStudent(s1[i]); 
    }  
return 0;
}