#include<iostream>
 using namespace std;
 
 struct Book{  
	char title[10];
	char author[10];
	int year;
	int Pages;
	
};
int main()
{
	Book book[5];
	for(int i=0; i<5; i++){
		cout<<"Enter the details for Book "<<i+1<<": "<<endl;
		cout<<"Enter the title: "<<endl;
		cin.getline(book[i].title,10);
		
		cout<<"Enter the author :"<<endl;
	    cin.getline(book[i].author,10);
		
		cout<<"Enter year of publication:"<<endl;
		cin>>book[i].year;
		
		cout<<"Enter the No of pages:"<<endl;
	    cin>>book[i].Pages;
		 cout<<endl;
		//Clear the input buffer
	    	cin.ignore();
	}
	for(int i=0; i<5; i++) {
	 	cout << "Information for Book "<<i+1<<endl;
	 	cout<<"Title:"<<book[i].title<<endl;
	 	cout<<"Author"<<book[i].author<<endl;
	 	cout<<"Year Of Publication:"<<book[i].year<<endl;
	 	cout<<"No. of pages:"<<book[i].Pages<<endl;
	 	
	  	
	} cout<<endl;
	
return 0;
}