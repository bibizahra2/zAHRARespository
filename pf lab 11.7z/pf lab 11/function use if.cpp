
 #include<iostream>
 using namespace std;
 struct User{  
	string variableName;	
};
int main()
{
	User username;
	string Username="zahra";
	cout<<"Enter your username:"<<endl;
	getline(cin,username.variableName);
    
    if(username.variableName==Username){
    	cout<<"You are successfully log in"<<endl;
	}
    else
    cout<<"Invalid"<<endl;
return 0;
}