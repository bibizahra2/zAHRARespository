#include<iostream>
using namespace std;
void multiply(int a,int b);
void subtraction(int a,int b);
void sum (int a,int b);
int main()
{
	int a,b;
	cout<<"enter your two number";
	cin>>a>>b;
	multiply(a,b); // function call
	subtraction(a,b); // function call
	sum(a,b); // function call
	return 0;
}
// function defination
	void multiply(int a,int b)
	{
	int m=a*b;
	cout<<m;
}
void subtraction(int a,int b)
{
	int sub=a-b;
	cout<<sub;
}
void sum(int a,int b)
{
	int s=a+b;
	cout<<s;
	
}