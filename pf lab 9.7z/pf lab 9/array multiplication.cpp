#include<iostream>
using namespace std;
int main()
	{
	int arr[3][2]={{6,3},{7,8},{4,5}};
	int mul;
	for(int i=0;i<3;i++)
	{
	for(int j=0;j<2;j++)
	{
	cout<<"element["<<i<<"]["<<j<<"]:";
	cin>>arr[i][j];
		mul=arr[i][j]*arr[i][j]; 	
	}
}
cout<<mul;
		cout<<endl;
	return 0;
}