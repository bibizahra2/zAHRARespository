#include<iostream>
using namespace std;
int main()
{
	int rows;
	cout<<"enter the rows"<<endl;
	cin>>rows;
	int col;
	cout<<"enter the colums"<<endl;
	cin>>col;
	int sum=0;
	float average=0.0;
	int arr[rows][col];
	cout<<"enter your arry element";
	for(int i=0;i<rows;i++)
	{
	for(int j=0;j<col;j++)
	{
	cout<<"element["<<i<<"]["<<j<<"]:";
	cin>>arr[i][j];
		sum=sum+arr[i][j];
		average=sum/arr[i][j]; 	
	}
	//display 2d array
	cout<<"\n the 2d array is:"<<endl;
	for(int i=0;i<rows;i++)
	{
		for(int j=0;j<col;j++)
		cout<<arr[i][j]<<" ";
	}
	cout<<endl;
}
cout<<sum;
		cout<<endl;
cout<<average;
	return 0;
}