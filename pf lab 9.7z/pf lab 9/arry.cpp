#include<iostream>
using namespace std;
int main()
{
	int rows;
	cout<<"enter the rows"<<endl;
	cin>>rows;
	int col;
	cout<<"enter the colums"<<endl;
	cin>>col;
	int arr[rows][col];
	cout<<"enter your arry element";
	for(int i=0;i<rows;i++)
	{
	for(int j=0;j<col;j++)
	{
	cout<<"element["<<i<<"]["<<j<<"]:";
	cin>>arr[i][j];
		
	}
	//display 2d array
	cout<<"\n the 2d array is:"<<endl;
	for(int i=0;i<rows;i++)
	{
		for(int j=0;j<col;j++)
		cout<<arr[i][j]<<" ";
	}
	cout<<endl;
}
	return 0;
}