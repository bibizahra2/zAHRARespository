#include<iostream>
using namespace std;
int main()
{
	int i,j,z;
	for( i=1;i<=5;i++)
	{
		for(z=1;z<=5-i;z++)
		{
			cout<<" ";
	}
		for(j=1;j<=2*i-1;j++)
		{
			cout<<"*";
		}
		cout<<endl;
	}
}