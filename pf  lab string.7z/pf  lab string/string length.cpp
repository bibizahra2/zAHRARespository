#include<iostream>
#include<cstring>
using namespace std;
int main()
{
	string str="hello,world !";
	int length=str.length();
	cout<<"the length of the string is:"<<length<<endl;
	return 0;
}