#include<iostream>
#include<cstring>
using namespace std;
int main()
{
	string str1="hello";
	string str2="world";
string result=str1+str2;
cout<<"concatenated string:"<<result;
return 0;
}