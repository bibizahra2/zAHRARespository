#include<iostream>
#include<cstring>
using namespace std;
int main()
{
	string str1,str2;
	str1="hello";
	str2="world";
	cout<<str1.append(str2);
	return 0;
}